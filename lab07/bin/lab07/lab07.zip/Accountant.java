package lab07;

public interface Accountant {
	
	int AGE_LIMIT = 26;
	double RATE_PIT = 0.18;
	double HCC = 0.09;
	
	double countSalary();
}
